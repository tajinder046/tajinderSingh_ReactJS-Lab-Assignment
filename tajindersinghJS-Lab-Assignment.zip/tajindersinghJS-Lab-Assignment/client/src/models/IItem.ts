export default interface IItem {
    
        payeeName: string,
        product: string,
        price: number,
        setDate: string,
        id: number
      
}